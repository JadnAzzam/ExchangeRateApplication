package com.hekmat.exchange.fluctuation;
import com.hekmat.exchange.api.ExchangeService;
import com.hekmat.exchange.api.model.FluctuationStatistics;
import javafx.application.Platform;
import javafx.fxml.Initializable;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.XYChart;

import javafx.scene.control.RadioButton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import java.net.URL;
import java.util.ResourceBundle;

public class Fluctuation implements Initializable {
  public LineChart chart;
  public NumberAxis y_axis;
  public CategoryAxis x_axis;
  public RadioButton radio_usd_lbp;
  public RadioButton radio_lbp_usd;
  XYChart.Series series1;
  XYChart.Series series2;
  private boolean state1;
  private boolean state2;

  public void initialize(URL url, ResourceBundle resourceBundle) {
    ExchangeService.exchangeApi().getExchangeRateOverTime().enqueue(new Callback<FluctuationStatistics>() {
      @Override
      public void onResponse(Call<FluctuationStatistics> call, Response<FluctuationStatistics> response) {
        FluctuationStatistics body = response.body();
        Platform.runLater(() -> {
          chart.setAnimated(false);

          // label axes
          y_axis.setLabel("Exchange Rate");
          x_axis.setLabel("Time");

          
          series1 = new XYChart.Series();
          series2 = new XYChart.Series();
          series1.setName("USD to LBP");
          series2.setName("LBP to USD");

          int axis_size = body.getUsd_to_lbp_rates().size();
          for (int i = 0; i < axis_size; i++) {
            series1.getData().add(new XYChart.Data(body.getUsd_to_lbp_rates_dates().get(i), body.getUsd_to_lbp_rates().get(i)));
            series2.getData().add(new XYChart.Data(body.getLbp_to_usd_rates_dates().get(i), body.getLbp_to_usd_rates().get(i)));
          }
          chart.getData().add(series1);
          chart.getData().add(series2);
        });
        state1 = true;
        state2 = true;
      }

      @Override
      public void onFailure(Call<FluctuationStatistics> call, Throwable throwable) {
        System.out.println("Fluctuation Statistics Fetching Failed.");
        System.out.println(throwable);
      }
    });
  }

  public void swap() {
    if (!radio_usd_lbp.isSelected() && state1 == true) {
      chart.getData().remove(series1);
      state1 = false;
    } else if (radio_usd_lbp.isSelected() && state1 == false) {
      chart.getData().add(series1);
      state1 = true;
    }
    if (!radio_lbp_usd.isSelected() && state2 == true) {
      chart.getData().remove(series2);
      state2 = false;
    } else if (radio_lbp_usd.isSelected() && state2 == false) {
      chart.getData().add(series2);
      state2 = true;
    }
  }
}
