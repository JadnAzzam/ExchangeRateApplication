package com.hekmat.exchange.transfer;

import com.hekmat.exchange.Authentication;
import com.hekmat.exchange.api.ExchangeService;
import com.hekmat.exchange.api.model.PeerTransaction;
import javafx.application.Platform;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Transfer {
  public Label sell_label;
  public Label buy_label;
  public TextField sell_field;
  public TextField buy_field;
  public TextField user_id;
  public RadioButton buy_usd_radio;
  public RadioButton sell_usd_radio;

  public void swap() {
    sell_field.setText("");
    buy_field.setText("");
    if (sell_usd_radio.isSelected()) {
      sell_label.setText("Send USD Amount");
      buy_label.setText("Receive LBP Amount");
    } else {
      sell_label.setText("Send LBP Amount");
      buy_label.setText("Receive USD Amount");
    }
  }

  private static boolean is_float(String s) {
    try {
      @SuppressWarnings("unused")
      Float x = Float.parseFloat(s);
      return true;
    } catch (NumberFormatException e) {
      return false;
    }
  }

  private static boolean is_integer(String s) {
    try {
      @SuppressWarnings("unused")
      Integer x = Integer.parseInt(s);
      return true;
    } catch (NumberFormatException e) {
      return false;
    }
  }

  public void transfer() {
    if (user_id.getText().isBlank() || sell_field.getText().isBlank() || buy_field.getText().isBlank()) {
      return;
    }
    if (!buy_usd_radio.isSelected() && !sell_usd_radio.isSelected()) {
      return;
    }
    if (!is_float(sell_field.getText()) || !is_float(buy_field.getText()) || !is_integer(user_id.getText())) {
      return;
    }
    Float sell = Float.parseFloat(sell_field.getText());
    Float buy = Float.parseFloat(buy_field.getText());
    Integer id = Integer.parseInt(user_id.getText());
    if (sell <= 0 || buy <= 0 || id < 0) {
      return;
    }
    if (buy_usd_radio.isSelected()) {
      Float foo = sell;
      sell = buy;
      buy = foo;
    }
    PeerTransaction peerTransaction = new PeerTransaction(
            sell,
            buy,
            sell_usd_radio.isSelected(),
            id
          );

    String userToken = Authentication.getInstance().getToken();
    String authHeader = userToken != null ? "Bearer " + userToken : null;

    ExchangeService.exchangeApi().transfer(peerTransaction, authHeader).enqueue(new Callback<Object>() {
      @Override
      public void onResponse(Call<Object> call, Response<Object> response) {
        Platform.runLater(() -> {
          sell_field.setText("");
          buy_field.setText("");
          user_id.setText("");
        });
      }

      @Override
      public void onFailure(Call<Object> call, Throwable throwable) {
      }
    });

  }
}
