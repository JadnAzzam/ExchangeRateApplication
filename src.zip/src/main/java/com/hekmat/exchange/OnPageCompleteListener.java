package com.hekmat.exchange;

public interface OnPageCompleteListener {
    public void onPageCompleted();
}