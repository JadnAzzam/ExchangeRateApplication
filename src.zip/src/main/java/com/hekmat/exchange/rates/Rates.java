package com.hekmat.exchange.rates;

import com.hekmat.exchange.Authentication;
import com.hekmat.exchange.api.ExchangeService;
import com.hekmat.exchange.api.model.Balance;
import com.hekmat.exchange.api.model.ExchangeRates;
import com.hekmat.exchange.api.model.Transaction;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Rates {
    public Label balance;
    public Label buyUsdRateLabel;
    public Label sellUsdRateLabel;
    public TextField lbpTextField;
    public TextField usdTextField;
    public ToggleGroup transactionType;
    public Label calcLabel1;
    public Label calcLabel2;
    public TextField calcTextField1;
    public TextField calcTextField2;
    public ToggleGroup calcType;
    public RadioButton calcBuyUsd;
    public RadioButton calcSellUsd;

    public void initialize() {
        fetchRates();
        displayBalance();
        calcSellUsd.setSelected(true);
        calcTextField2.setEditable(false);
    }

    private void fetchRates() {
        ExchangeService.exchangeApi().getExchangeRates().enqueue(new Callback<ExchangeRates>() {
            @Override
            public void onResponse(Call<ExchangeRates> call, Response<ExchangeRates> response) {
                ExchangeRates exchangeRates = response.body();
                Platform.runLater(() -> {
                    buyUsdRateLabel.setText(exchangeRates.lbpToUsd.toString());
                    sellUsdRateLabel.setText(exchangeRates.usdToLbp.toString());
                });
            }

            @Override
            public void onFailure(Call<ExchangeRates> call, Throwable throwable) {
            }
        });
    }

    public void addTransaction(ActionEvent actionEvent) {
        Transaction transaction = new Transaction(
                Float.parseFloat(usdTextField.getText()),
                Float.parseFloat(lbpTextField.getText()),
                ((RadioButton) transactionType.getSelectedToggle()).getText().equals("Sell USD"));
        String userToken = Authentication.getInstance().getToken();
        String authHeader = userToken != null ? "Bearer " + userToken : null;
        ExchangeService.exchangeApi().addTransaction(transaction, authHeader).enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                fetchRates();
                Platform.runLater(() -> {
                    usdTextField.setText("");
                    lbpTextField.setText("");
                });
            }

            @Override
            public void onFailure(Call<Object> call, Throwable throwable) {
            }
        });
    }

    public void swap(ActionEvent actionEvent) {
        calcTextField1.setText("");
        calcTextField2.setText("");
        if (calcSellUsd.isSelected()) {
            calcLabel1.setText("USD Amount");
            calcLabel2.setText("LBP Amount");
        } else {
            calcLabel2.setText("USD Amount");
            calcLabel1.setText("LBP Amount");
        }
    }

    public void calculate() {
        if (calcTextField1.getText().isBlank() && calcTextField2.getText().isBlank()) {
            return;
        }
        float amount_usd = Float.parseFloat(calcTextField1.getText());
        if (calcSellUsd.isSelected()) {
            calcTextField2.setText(Float.toString(amount_usd * Float.parseFloat(sellUsdRateLabel.getText())));
        } else if (calcBuyUsd.isSelected()) {
            calcTextField2.setText(Float.toString(amount_usd / Float.parseFloat(buyUsdRateLabel.getText())));
        }
    }

    public void displayBalance() {
        String token = Authentication.getInstance().getToken();
        boolean authenticated = token != null;
        if (authenticated) {
            ExchangeService.exchangeApi().getBalance("Bearer " + token).enqueue(new Callback<Balance>() {
                @Override
                public void onResponse(Call<Balance> call, Response<Balance> response) {
                    Balance body = response.body();
                    Platform.runLater(() -> {
                        balance.setText(
                                "Hello! Your USD balance is $" + body.getUsd_amount_owned() + " and your LBP balance is " + body.getLbp_amount_owned() + "LBP"
                        );
                    });
                }
                @Override
                public void onFailure(Call<Balance> call, Throwable throwable) {
                    System.out.println(throwable);
                }
            });
        } else {
            balance.setText("");
        }
    }

}