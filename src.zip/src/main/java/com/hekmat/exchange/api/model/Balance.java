package com.hekmat.exchange.api.model;

import com.google.gson.annotations.SerializedName;

public class Balance {
  @SerializedName("user_usd_amount_owned")
  public Float usd_amount_owned;

  @SerializedName("user_lbp_amount_owned")
  public Float lbp_amount_owned;

  public Balance(Float usd_amount_owned, Float lbp_amount_owned) {
    this.usd_amount_owned = usd_amount_owned;
    this.lbp_amount_owned = lbp_amount_owned;
  }

  public Float getUsd_amount_owned() {
    return usd_amount_owned;
  }

  public Float getLbp_amount_owned() {
    return lbp_amount_owned;
  }
}
