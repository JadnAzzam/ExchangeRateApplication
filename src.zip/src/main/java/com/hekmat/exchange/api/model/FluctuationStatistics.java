package com.hekmat.exchange.api.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class FluctuationStatistics {
  @SerializedName("usd_to_lbp_ratesOverTime")
  List<Float> usd_to_lbp_rates;

  @SerializedName("lbp_to_usd_ratesOverTime")
  List<Float> lbp_to_usd_rates;

  @SerializedName("usd_to_lbp_ratesOverTime_dates")
  List<String> usd_to_lbp_rates_dates;

  @SerializedName("lbp_to_usd_ratesOverTime_dates")
  List<String> lbp_to_usd_rates_dates;

  @SerializedName("sell_usd_max_rate")
  Float sell_usd_max_rate;

  @SerializedName("buy_usd_max_rate")
  Float buy_usd_max_rate;

  @SerializedName("sell_usd_min_rate")
  Float sell_usd_min_rate;

  @SerializedName("buy_usd_min_rate")
  Float buy_usd_min_rate;

  @SerializedName("num_of_sell_usd_transactions")
  Integer num_of_sell;

  @SerializedName("num_of_buy_usd_transactions")
  Integer num_of_buy;

  @SerializedName("std_dev_sell_usd")
  Float std_sell_usd;

  @SerializedName("std_dev_buy_usd")
  Float std_buy_usd;

  public List<Float> getUsd_to_lbp_rates() {
    return usd_to_lbp_rates;
  }

  public List<Float> getLbp_to_usd_rates() {
    return lbp_to_usd_rates;
  }

  public List<String> getUsd_to_lbp_rates_dates() {
    return usd_to_lbp_rates_dates;
  }

  public List<String> getLbp_to_usd_rates_dates() {
    return lbp_to_usd_rates_dates;
  }

  public Float getSell_usd_max_rate() {
    return sell_usd_max_rate;
  }

  public Float getBuy_usd_max_rate() {
    return buy_usd_max_rate;
  }

  public Float getSell_usd_min_rate() {
    return sell_usd_min_rate;
  }

  public Float getBuy_usd_min_rate() {
    return buy_usd_min_rate;
  }

  public Integer getNum_of_sell() {
    return num_of_sell;
  }

  public Integer getNum_of_buy() {
    return num_of_buy;
  }

  public Float getStd_sell_usd() { return std_sell_usd; }

  public Float getStd_buy_usd() { return std_buy_usd; }
}
