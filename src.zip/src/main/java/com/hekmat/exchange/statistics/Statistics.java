package com.hekmat.exchange.statistics;

import com.hekmat.exchange.api.ExchangeService;
import com.hekmat.exchange.api.model.FluctuationStatistics;
import javafx.application.Platform;
import javafx.scene.control.Label;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Statistics {
  public Label buyUsdMaxRateLabel;
  public Label sellUsdMaxRateLabel;
  public Label buyUsdMinRateLabel;
  public Label sellUsdMinRateLabel;
  public Label totalBuyUsd;
  public Label totalSellUsd;
  public Label std_buy_usd;
  public Label std_sell_usd;

  public void initialize() {
    ExchangeService.exchangeApi().getExchangeRateOverTime().enqueue(new Callback<FluctuationStatistics>() {
      @Override
      public void onResponse(Call<FluctuationStatistics> call, Response<FluctuationStatistics> response) {
        FluctuationStatistics stats = response.body();
        Platform.runLater(() -> {
          buyUsdMaxRateLabel.setText(stats.getBuy_usd_max_rate().toString());
          sellUsdMaxRateLabel.setText(stats.getSell_usd_max_rate().toString());
          buyUsdMinRateLabel.setText(stats.getBuy_usd_min_rate().toString());
          sellUsdMinRateLabel.setText(stats.getSell_usd_min_rate().toString());
          totalBuyUsd.setText(stats.getNum_of_buy().toString());
          totalSellUsd.setText(stats.getNum_of_sell().toString());
          std_buy_usd.setText(stats.getStd_buy_usd().toString());
          std_sell_usd.setText(stats.getStd_sell_usd().toString());
        });
      }

      @Override
      public void onFailure(Call<FluctuationStatistics> call, Throwable throwable) {
      }
    });
  }
}
