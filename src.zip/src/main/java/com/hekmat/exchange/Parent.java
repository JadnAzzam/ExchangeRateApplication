package com.hekmat.exchange;

import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class Parent implements Initializable, OnPageCompleteListener{
    public BorderPane borderPane;
    public Button transactionButton;
    public Button loginButton;
    public Button registerButton;
    public Button logoutButton;
    public Button fluctuationButton;
    public Button transferButton;
    public Button inboxButton;
    public Button replyButton;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        updateNavigation();
    }
    public void ratesSelected() {
        swapContent(Section.RATES);
    }

    public void transactionsSelected() {
        swapContent(Section.TRANSACTIONS);
    }

    public void loginSelected() {
        swapContent(Section.LOGIN);
    }

    public void registerSelected() {
        swapContent(Section.REGISTER);
    }

    public void fluctuationSelected() {
        swapContent(Section.FLUCTUATION);
    }

    public void statisticsSelected() { swapContent(Section.STATISTICS); }

    public void transferSelected() { swapContent(Section.TRANSFER); }

    public void inboxSelected() { swapContent(Section.INBOX); }

    public void replySelected() { swapContent(Section.REPLY); }

    public void logoutSelected() {
        Authentication.getInstance().deleteToken();
        swapContent(Section.RATES);
    }

    private void swapContent(Section section) {
        try {
            URL url = getClass().getResource(section.getResource());
            FXMLLoader loader = new FXMLLoader(url);
            borderPane.setCenter(loader.load());
            if (section.doesComplete()) {
                ((PageCompleter)
                        loader.getController()).setOnPageCompleteListener(this);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        updateNavigation();
    }

    @Override
    public void onPageCompleted() {
        swapContent(Section.RATES);
    }

    private enum Section {
        RATES,
        TRANSACTIONS,
        LOGIN,
        REGISTER,
        FLUCTUATION,
        STATISTICS,
        TRANSFER,
        INBOX,
        REPLY;

        public boolean doesComplete() {
            return switch (this) {
                case LOGIN, REGISTER -> true;
                default -> false;
            };
        }

        public String getResource() {
            return switch (this) {
                case RATES ->
                        "/com/hekmat/exchange/rates/rates.fxml";
                case TRANSACTIONS ->
                        "/com/hekmat/exchange/transactions/transactions.fxml";
                case LOGIN ->
                        "/com/hekmat/exchange/login/login.fxml";
                case REGISTER ->
                        "/com/hekmat/exchange/register/register.fxml";
                case FLUCTUATION ->
                        "/com/hekmat/exchange/fluctuation/fluctuation.fxml";
                case STATISTICS ->
                        "/com/hekmat/exchange/statistics/statistics.fxml";
                case TRANSFER ->
                        "/com/hekmat/exchange/transfer/transfer.fxml";
                case INBOX ->
                        "/com/hekmat/exchange/inbox/inbox.fxml";
                case REPLY ->
                        "/com/hekmat/exchange/reply/reply.fxml";
                default -> null;
            };
        }

    }

    private void updateNavigation() {
        boolean authenticated = Authentication.getInstance().getToken() != null;
        transactionButton.setManaged(authenticated);
        transactionButton.setVisible(authenticated);
        loginButton.setManaged(!authenticated);
        loginButton.setVisible(!authenticated);
        registerButton.setManaged(!authenticated);
        registerButton.setVisible(!authenticated);
        logoutButton.setManaged(authenticated);
        logoutButton.setVisible(authenticated);
        transferButton.setManaged(authenticated);
        transferButton.setVisible(authenticated);
        inboxButton.setManaged(authenticated);
        inboxButton.setVisible(authenticated);
        replyButton.setManaged(authenticated);
        replyButton.setVisible(authenticated);
    }
}

