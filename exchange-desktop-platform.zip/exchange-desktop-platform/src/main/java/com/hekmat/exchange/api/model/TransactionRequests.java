package com.hekmat.exchange.api.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class TransactionRequests {
  @SerializedName("pendingSentRequests")
  public List<PeerTransaction> pendingSent;

  @SerializedName("pendingReceivedRequests")
  public List<PeerTransaction> pendingReceived;

  @SerializedName("acceptedSentRequests")
  public List<PeerTransaction> acceptedSent;

  @SerializedName("rejectedSentRequests")
  public List<PeerTransaction> rejectedSent;

  public List<PeerTransaction> getPendingSent() {
    return pendingSent;
  }

  public List<PeerTransaction> getPendingReceived() {
    return pendingReceived;
  }

  public List<PeerTransaction> getAcceptedSent() {
    return acceptedSent;
  }

  public List<PeerTransaction> getRejectedSent() {
    return rejectedSent;
  }
}
