package com.hekmat.exchange;

public interface PageCompleter {
    void setOnPageCompleteListener(OnPageCompleteListener onPageCompleteListener);
}
