package com.hekmat.exchange.inbox;

import com.hekmat.exchange.Authentication;
import com.hekmat.exchange.api.ExchangeService;
import com.hekmat.exchange.api.model.PeerTransaction;
import com.hekmat.exchange.api.model.TransactionRequests;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.net.URL;
import java.util.ResourceBundle;

public class Inbox implements Initializable {
  public TableColumn lbpAmount;
  public TableColumn usdAmount;
  public TableColumn usdToLbp;
  public TableColumn senderId;
  public TableColumn transactionId;
  public TableColumn status;
  public TableView tableView;

  @Override
  public void initialize(URL url, ResourceBundle resourceBundle) {
    lbpAmount.setCellValueFactory(new PropertyValueFactory<>("lbpAmount"));
    usdAmount.setCellValueFactory(new PropertyValueFactory<>("usdAmount"));
    usdToLbp.setCellValueFactory(new PropertyValueFactory<>("usdToLbp"));
    senderId.setCellValueFactory(new PropertyValueFactory<>("senderId"));
    transactionId.setCellValueFactory(new PropertyValueFactory<>("id"));
    status.setCellValueFactory(new PropertyValueFactory<>("exchangeStage"));

    String userToken = Authentication.getInstance().getToken();
    String authHeader = userToken != null ? "Bearer " + userToken : null;
    ExchangeService.exchangeApi().getTransactionRequests(authHeader).enqueue(new Callback<TransactionRequests>() {
      @Override
      public void onResponse(Call<TransactionRequests> call, Response<TransactionRequests> response) {
        for (PeerTransaction row : response.body().getPendingReceived()) {
          row.exchangeStage = "pending";
          tableView.getItems().add(row);
        }
        for (PeerTransaction row : response.body().getAcceptedSent()) {
          row.exchangeStage = "accepted";
          tableView.getItems().add(row);
        }
        for (PeerTransaction row : response.body().getRejectedSent()) {
          row.exchangeStage = "rejected";
          tableView.getItems().add(row);
        }
        for (PeerTransaction row : response.body().getPendingSent()) {
          row.exchangeStage = "pending";
          tableView.getItems().add(row);
        }
      }

      @Override
      public void onFailure(Call<TransactionRequests> call, Throwable throwable) {
        System.out.println(throwable);
      }
    });
  }
}
