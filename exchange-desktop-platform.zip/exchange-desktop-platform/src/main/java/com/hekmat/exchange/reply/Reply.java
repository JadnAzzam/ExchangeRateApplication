package com.hekmat.exchange.reply;

import com.hekmat.exchange.Authentication;
import com.hekmat.exchange.api.ExchangeService;
import com.hekmat.exchange.api.model.RequestReply;
import javafx.application.Platform;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Reply {
  public TextField transactionID;
  public RadioButton accept_radio;
  public RadioButton decline_radio;

  private static boolean is_integer(String s) {
    try {
      @SuppressWarnings("unused")
      Integer x = Integer.parseInt(s);
      return true;
    } catch (NumberFormatException e) {
      return false;
    }
  }

  public void submit() {
    if (!accept_radio.isSelected() && !decline_radio.isSelected()) {
      return;
    }
    if (!is_integer(transactionID.getText())) {
      return;
    }
    int transaction_id = Integer.parseInt(transactionID.getText());
    if (transaction_id < 1) {
      return;
    }
    RequestReply reply_ = new RequestReply(transaction_id, (accept_radio.isSelected() ? "accepted" : "rejected"));
    String userToken = Authentication.getInstance().getToken();
    String authHeader = userToken != null ? "Bearer " + userToken : null;

    ExchangeService.exchangeApi().reply(reply_, authHeader).enqueue(new Callback<>() {
      @Override
      public void onResponse(Call<Object> call, Response<Object> response) {
        System.out.println("Success");
        Platform.runLater(() -> transactionID.setText(""));
      }

      @Override
      public void onFailure(Call<Object> call, Throwable throwable) {
        System.out.println(throwable);
        System.out.println("Failed");
      }
    });
  }
}
