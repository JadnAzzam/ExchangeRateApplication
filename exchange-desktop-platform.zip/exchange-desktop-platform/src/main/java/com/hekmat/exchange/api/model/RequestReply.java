package com.hekmat.exchange.api.model;

import com.google.gson.annotations.SerializedName;

public class RequestReply {
  @SerializedName("transaction_id")
  public Integer transactionId;

  @SerializedName("accepted")
  public String accepted;

  public RequestReply(Integer transactionId, String accepted) {
    this.transactionId = transactionId;
    this.accepted = accepted;
  }
}
