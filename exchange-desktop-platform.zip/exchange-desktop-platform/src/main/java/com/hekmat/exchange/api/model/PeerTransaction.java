package com.hekmat.exchange.api.model;

import com.google.gson.annotations.SerializedName;

public class PeerTransaction {
  @SerializedName("usd_amount")
  public Float usdAmount;

  @SerializedName("lbp_amount")
  public Float lbpAmount;

  @SerializedName("usd_to_lbp")
  public Boolean usdToLbp;

  @SerializedName("id")
  public Integer id;

  @SerializedName("sender_id")
  public Integer senderId;

  @SerializedName("receiver_id")
  public Integer receiverId;

  @SerializedName("exchange_stage")
  public String exchangeStage;

  public PeerTransaction(Float usdAmount, Float lbpAmount, Boolean usdToLbp, Integer receiverId) {
    this.usdAmount = usdAmount;
    this.lbpAmount = lbpAmount;
    this.usdToLbp = usdToLbp;
    this.receiverId = receiverId;
  }

  public Float getUsdAmount() {
    return usdAmount;
  }

  public Float getLbpAmount() {
    return lbpAmount;
  }

  public Boolean getUsdToLbp() {
    return usdToLbp;
  }

  public Integer getId() {
    return id;
  }

  public Integer getSenderId() {
    return senderId;
  }

  public Integer getReceiverId() {
    return receiverId;
  }

  public String getExchangeStage() {
    return exchangeStage;
  }
}
