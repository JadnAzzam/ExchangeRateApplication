module com.hekmat.exchange {
    requires javafx.controls;
    requires javafx.fxml;
    requires retrofit2;
    requires java.sql;
    requires gson;
    requires retrofit2.converter.gson;
    requires java.prefs;
    opens com.hekmat.exchange to javafx.fxml;
    opens com.hekmat.exchange.api.model to javafx.base, gson;
    exports com.hekmat.exchange;
    opens com.hekmat.exchange.api to gson;
    exports com.hekmat.exchange.rates;
    opens com.hekmat.exchange.rates to javafx.fxml;
    opens com.hekmat.exchange.login to javafx.fxml;
    opens com.hekmat.exchange.register to javafx.fxml;
    opens com.hekmat.exchange.transactions to javafx.fxml;
    exports com.hekmat.exchange.fluctuation;
    exports com.hekmat.exchange.statistics;
    exports com.hekmat.exchange.transfer;
    exports com.hekmat.exchange.inbox;
    exports com.hekmat.exchange.reply;
    opens com.hekmat.exchange.fluctuation to javafx.fxml;
    opens com.hekmat.exchange.statistics to javafx.fxml;
    opens com.hekmat.exchange.transfer to javafx.fxml;
    opens com.hekmat.exchange.inbox to javafx.fxml;
    opens com.hekmat.exchange.reply to javafx.fxml;
}
